def wordBreak(s, wordDict):
    """
    :type s: str
    :type wordDict: List[str]
    :rtype: bool
    """
    n, m = len(s), len(wordDict)
    if m == 0 and n != 0:
        return False
    if m == 0 and n == 0:
        return True

    dp = [False] * (n + 1)
    dp[0] = True
    for i in range(n):
        for elem in wordDict:
            if dp[i] and s[i:i + len(elem)] == elem and i + len(elem) <= n:
                dp[i + len(elem)] = True
    return dp[n]

s = "leetcode"
wordDict = ["leet", "code"]
s1 = "applepenapple"
wordDict1 = ["apple", "pen"]
s2 = "catsandog"
wordDict2 = ["cats", "dog", "sand", "and", "cat"]
s3 = "a"
wordDict3 = []
s4 = "bb"
wordDict4 = ["a","b","bbb","bbbb"]
print(wordBreak(s2, wordDict2))
