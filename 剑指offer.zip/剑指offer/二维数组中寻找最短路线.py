def getPath(arr):
    row = len(arr)
    col = len(arr[0])
    if row == 0:
        return 0
    dp = [[0 for i in range(col)] for j in range(row)]
    #pathArr = [[[] for i in range(col)] for j in range(row)]
    tmp = []
    dp[0][0] = arr[0][0]
    tmp.append((0, 0))
    for i in range(1, row):
        dp[i][0] = dp[i-1][0] + arr[i][0]
        if col == 1:
            tmp.append((i, 0))
    for j in range(1, col):
        dp[0][j] = dp[0][j-1] + arr[0][j]
        if row == 1:
            tmp.append((0, j))

    for i in range(1, row):
        for j in range(1, col):
            # dp[i][j] = min(dp[i-1][j], dp[i][j-1])+arr[i][j]
            if dp[i-1][j] < dp[i][j-1]:
                dp[i][j] = dp[i-1][j] + arr[i][j]
                tmp.append((i-1, j))
            else:
                dp[i][j] = dp[i][j-1] + arr[i][j]
                tmp.append((i, j-1))
    tmp.append((row-1, col-1))
    print(tmp)
    return dp[row-1][col-1]

arr = [[1,4,3],[8,7,5],[2,1,5]]
#arr1 = [[1,2,3]]
length = getPath(arr)
print(length)

