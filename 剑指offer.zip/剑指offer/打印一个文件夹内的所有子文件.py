#-*- coding:utf-8 -*-
import os

def printDir(path, pathList, dic):
    for elem in os.listdir(path):
        folderPath = os.path.join(path, elem)
        if os.path.isdir(folderPath):
            printDir(folderPath, pathList, dic)
        else:
            key = folderPath.split('\\')[-1]
            v = os.path.getsize(folderPath)
            dic[key] = v
            pathList.append(folderPath)
def printMaxSize(dic, n):
    result = sorted(dic.items(), key=lambda dic:dic[1], reverse=True)
    for i in range(n):
        print(result[i])

path="C:\\Users\\i349097\\OneDrive - SAP SE\\Documents\\myFile"
#counter = 0
dic = {}
pathList = []
printDir(path, pathList, dic)
printMaxSize(dic, 10)
#print(len(pathList))
