arr = []
strArr = [str(x) for x in arr]
headArr = []
for i,elem in enumerate(strArr):
    if len(headArr) == 0:
        headArr.append(elem[0])
        res.append(elem)
        continue
    for i, e in headArr:
        if elem[0] > e:
            headArr.insert(i)