
def wordSearch(board, word):
    m, n = len(board), len(board[0])
    index = 0
    for i in range(m):
        for j in range(n):
            if dfs(board, word, i, j, index):
                return True
    return False

def dfs(board, word, i, j, index):
    # import pdb
    # pdb.set_trace()
    if index >= len(word):
        return True
    if i < 0 or i >= len(board) or j < 0 or j >= len(board[0]):
        return False
    if board[i][j] != word[index]:
        return False
    temp = board[i][j]
    board[i][j] = '0'
    res = dfs(board, word, i-1, j, index+1) or dfs(board, word, i, j+1, index+1) or dfs(board, word, i+1, j, index+1) or dfs(board, word, i, j-1, index+1)
    board[i][j] = temp
    return res

board =[
  ['A','B','C','E'],
  ['S','F','C','S'],
  ['A','D','E','E']
]
word = "ABCCED"
if wordSearch(board, word):
    print('true')
else:
    print('false')