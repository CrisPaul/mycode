class Solution:
    def sumNumbers(self, root: 'TreeNode') -> 'int':
        '''
        深度优先遍历，递归执行每一条路径上的数字计算求和
        '''
        self.sum = 0

        def dfs(root, pathsum):
          if root:
            pathsum += root.val
            left = dfs(root.left, pathsum * 10)
            right = dfs(root.right, pathsum * 10)
            if not left and not right:
              self.sum += pathsum
            return True

        dfs(root, 0)
        return self.sum