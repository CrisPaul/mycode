class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None
def isSameTree(p, q):
    """
    :type p: TreeNode
    :type q: TreeNode
    :rtype: bool
    """
    if p == None and q == None:
        return True
    elif (p == None and q != None) or (p != None and q == None):
        return False
    elif p.val != q.val:
        return False

    p1 = isSameTree(p.left, q.left)
    q1 = isSameTree(p.right, q.right)
    if q1 and q1:
        return True

def arrayToTree(arr, start, end):
    root = None
    # import pdb
    # pdb.set_trace()
    if end >= start:
        if start+end >= 2:
            mid = (start + end) // 2
        else:
            mid = 0
        root = TreeNode(arr[mid])
        if mid >= 1:
            root.left = arrayToTree(arr, start, mid-1)
        else:
            root.left = None
        root.right = arrayToTree(arr, mid+1, end)
    else:
        root = None
    return root

# a1 = [1,2,3]
# a2 = [1,2,3]
a1 = [1, 2]
a2 = [1, None, 2]
t1 = arrayToTree(a1, 0, len(a1)-1)
t2 = arrayToTree(a2, 0, len(a2)-1)
print(isSameTree(t1,t2))