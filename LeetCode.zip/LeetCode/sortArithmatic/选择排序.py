def selectSort(aList):
    if len(aList) == 1:
        return [aList[0]]
    for i in range(1, len(aList)):
        if aList[i] < aList[0]:
            aList[0], aList[i] = aList[i], aList[0]
    return [aList[0]] + selectSort(aList[1:])

aList = [13, 65, 97, 76, 38, 27, 49]
print(selectSort(aList))