def partition(head, x):
    linkedList = head.split('->')
    # import  pdb
    # pdb.set_trace()
    pos = linkedList.index(str(x))
    for i in range(len(linkedList)):
        if linkedList[i] < linkedList[pos] and i > pos:
            tmp = linkedList[i]
            del(linkedList[i])
            linkedList.insert(pos, tmp)
            pos += 1
            # pos = i
    sub1List, sub2List = linkedList[:pos], linkedList[pos:]
    sub1List.sort()
    return '->'.join(sub1List + sub2List)



#输入: head = 1->4->3->2->5->2, x = 3
head = '1->4->3->2->5->2'
x = 3
partition(head, x)
