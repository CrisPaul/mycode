class Solution:
    def letterCombinations(self, digits):
        """
        :type digits: str
        :rtype: List[str]
        """
        dic = {
            '2':['a','b','c'],
            '3':['d','e','f'],
            '4':['g','h','i'],
            '5':['j','k','l'],
            '6':['m','n','o'],
            '7':['p','q','r','s'],
            '8':['t','u','v'],
            '9':['w','x','y','z']
               }
        # import pdb
        # pdb.set_trace()
        res = []
        if len(digits) == 0:
            return []
        if len(digits) == 1:
            return dic[digits[0]]
        tmpRes = self.letterCombinations(digits[1:])
        for t in tmpRes:
            for d in dic[digits[0]]:
                res.append(d+t)
        return res

s = Solution()
numStr = "23"
t = s.letterCombinations(numStr)
print(t)