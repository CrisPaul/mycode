def minimumTotal(triangle):
    """
    :type triangle: List[List[int]]
    :rtype: int
    """
    # import pdb
    # pdb.set_trace()
    m = len(triangle)
    if m == 0:
        return 0
    dp = [[0 for j in range(m)] for i in range(m+1)]
    for i in range(1, m+1):
        dp[i][0] = dp[i-1][0] + triangle[i-1][0]
    # import pdb
    # pdb.set_trace()
    for i in range(1, m+1):
        j = 1

        while j < len(triangle[i-1]):
            if j == len(triangle[i-1])-1:
                dp[i][j] = triangle[i-1][j]+dp[i-1][j-1]
            else:
                dp[i][j] = min(triangle[i-1][j]+dp[i-1][j-1], triangle[i-1][j]+dp[i-1][j])
            j += 1
    return min(dp[m])
    #return dp[m]
t =[
     [2],
    [3,4],
   [6,5,7],
  [4,1,8,3]
]

# t = [[-1],[-2,-3]]
print(minimumTotal(t))