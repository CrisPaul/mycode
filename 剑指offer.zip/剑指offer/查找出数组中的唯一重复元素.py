def findDup(arr):
    if len(arr) == 0:
        return
    res = 0
    i = 0
    while i < len(arr):
        res ^= arr[i]
        i += 1
    j = 1
    while j < len(arr):
        res ^= j
        j += 1
    return res
arr = [1,2,3,4,5,6,7,8,5]
print(findDup(arr))