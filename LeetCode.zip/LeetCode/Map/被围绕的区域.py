class Solution:
    def solve(self, board: 'List[List[str]]') -> 'None':
        """
        Do not return anything, modify board in-place instead.
        """
        if not board:
            return None

        # m, n = len(board), len(board[0])
        # d = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        #
        # def _solve(i, j):
        #     if 0 <= i < m and 0 <= j < n and board[i][j] == 'O':
        #         board[i][j] = '*'
        #         for k in range(4):
        #             _solve(i + d[k][0], j + d[k][1])
        #
        # for i in range(m):
        #     _solve(i, 0)
        #     _solve(i, n - 1)
        #
        # for i in range(n):
        #     _solve(0, i)
        #     _solve(m - 1, i)
        #
        # for i in range(m):
        #     for j in range(n):
        #         if board[i][j] == 'O':
        #             board[i][j] = 'X'
        #         elif board[i][j] == '*':
        #             board[i][j] = 'O'
        m, n = len(board), len(board[0])
        d = [(-1, 0), (0, 1), (1, 0), (0, -1)]

        def _solve(i, j):
            if 0 <= i < m and 0 <= j < n and board[i][j] == 'O':
                board[i][j] = '-'
                for k in range(4):
                    _solve(i + d[k][0], j + d[k][1])

        for i in range(m):
            _solve(i, 0)
            _solve(i, m-1)

        for j in range(n):
            _solve(0, j)
            _solve(n-1, j)

        for i in range(m):
            for j in range(n):
                if board[i][j] == 'O':
                    board[i][j] = 'X'
                elif board[i][j] == '-':
                    board[i][j] = 'O'



s=Solution()
board = [
    ['X','X','X','X'],
    ['X','O','O','X'],
    ['X','X','O','X'],
    ['X','O','O','X']
]
board1 = [
["O","O","O"],["O","O","O"],["O","O","O"]
]
board2 = [
    ["X","X","X","X"],
    ["X","O","O","X"],
    ["X","X","O","X"],
    ["X","O","X","X"]
]
s.solve(board)
for elem in board:
    print(elem)


