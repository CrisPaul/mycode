def getMinPathSum(matrix):

    m, n = len(matrix), len(matrix[0])      # m是行数，n是列数
    dp = [[0 for j in range(n)] for i in range(m)]

    if m == 0 or n == 0:
        return
    if m == 1 and n == 1:
        return matrix[0][0]
    else:
        dp[0][0] = matrix[0][0]
        for j in range(1, n):
            dp[0][j] = dp[0][j-1] + matrix[0][j]
        for i in range(1, m):
            dp[i][0] = dp[i-1][0] + matrix[i][0]

        for i in range(1, m):
            for j in range(1, n):
                # import pdb
                # pdb.set_trace()
                dp[i][j] = matrix[i][j] + min(dp[i-1][j], dp[i][j-1])
        return dp[m-1][n-1]

matrix = [
  [1, 3, 1],
  [1, 5, 1],
  [4, 2, 1]
]
print(getMinPathSum(matrix))
