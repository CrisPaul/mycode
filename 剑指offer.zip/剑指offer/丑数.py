def getUglyNumber(index):
    if index < 0:
        return 0

    uglyNumList = []
    uglyNumList.append(1)

    nextUglyIndex=1
    i, j, k = 0, 0, 0
    numMultiply2 = uglyNumList[0]
    numMultiply3 = uglyNumList[0]
    numMultiply5 = uglyNumList[0]
    while nextUglyIndex < index:
        minNum = min(numMultiply2*2, numMultiply3*3, numMultiply5*5)
        uglyNumList.append(minNum)

        while numMultiply2*2 <= uglyNumList[-1]:
            numMultiply2 += 1
        while numMultiply3*3 <= uglyNumList[-1]:
            numMultiply3 += 1
        while numMultiply5*5 <= uglyNumList[-1]:
            numMultiply5 += 1

        nextUglyIndex += 1

    return uglyNumList[nextUglyIndex-1]

resNum = getUglyNumber(1500)
print(resNum)