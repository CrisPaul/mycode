def getMinNumOfArrays(array, p1, p2):
    #n = len(array)
    if array[p1] < array[p2]:
        return array[p1]
    while 1:
        if p2 - p1 <= 1:
            break
        mid = (p1 + p2) // 2
        if array[mid] >= array[p1]:
            p1 = mid
        if array[mid] <= array[p2]:
            p2 = mid
    return array[p2]

arr = [4,6,7,8,9,1,2,3]
arr1 = [1,2,3,6,8]
minNum = getMinNumOfArrays(arr,0,len(arr)-1)
minNum1 = getMinNumOfArrays(arr1,0,len(arr1)-1)
print(minNum, minNum1)
