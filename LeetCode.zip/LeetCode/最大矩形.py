# def func2(a, m, n):
#     flag = 1
#     for i in range(m):
#         if a[i][n] == "1" and a[i-1][n] == "1":
#             continue
#         else:
#             flag = 0
#             break
#     if flag:
#         return m
#     else:
#         return 0
# def func1(a, m, n):
#     flag = 1
#     for j in range(n):
#         if a[m][j] == "1" and a[m][j-1] == "1":
#             continue
#         else:
#             flag = 0
#             break
#     if flag:
#         return n
#     else:
#         return 0
# def maximalRectangle(matrix):
#     m, n = len(matrix), len(matrix[0])
#     # import pdb
#     # pdb.set_trace()
#     dp = [[ 1 for j in range(n)] for i in range(m)]
#     if matrix[0][0] == '0':
#         dp[0][0] = 0
#     else:
#         dp[0][0] = 1
#     for i in range(1, m):
#         dp[i][0] = dp[i-1][0] + func1(matrix, i, 1)
#     for j in range(1, n):
#         dp[0][j] = dp[0][j-1] + func2(matrix, 1, j)
#     import pdb
#     pdb.set_trace()
#     for i in range(1, m):
#         for j in range(1, n):
#             if func1(matrix, i, j) and func2(matrix, i, j) and matrix[i][j] == "1":
#                 dp[i][j] = dp[i-1][j-1] + func1(matrix, i, j) + func2(matrix, i, j) + 1
#             else:
#                 dp[i][j] = dp[i-1][j-1] + max(func1(matrix, i, j), func2(matrix, i, j))
#
#     return matrix[m-1][n-1]
def widthOfModule(postion, s):
    if not len(s):
        return postion
    else:
        return postion - s[-1] - 1

def maximalRectangle(matrix):
    m, n = len(matrix), len(matrix[0])
    if m == 0 or n == 0:
        return 0
    height = [0] * n
    maxValue = 0
    for i in range(m):
        for j in range(n):
            if matrix[i][j] == '1':
                height[j] += 1
            else:
                height[j] = 0
        res = []
        for j in range(n):
            if len(res) == 0 or height[j] > height[res[-1]]:
                res.append(j)
            else:
                while len(res) and height[j] < height[res[-1]]:
                    maxValue = max(maxValue, height[res.pop(-1)] * widthOfModule(j, res))
    return maxValue

matrix = [
  ["1","0","1","0","0"],
  ["1","0","1","1","1"],
  ["1","1","1","1","1"],
  ["1","0","0","1","0"]
]
print(maximalRectangle(matrix))

