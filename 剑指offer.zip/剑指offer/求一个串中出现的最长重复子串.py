def getLength(s1, s2):
    n1, n2 = len(s1), len(s2)
    i, j = 0, 0
    while i < n1 and j < n2:
        if s1[i] != s2[j]:
            break
        i += 1
        j += 1
    return i
def getMaxCommonStr(s):
    if len(s) == 0:
        return
    n = len(s)
    strList = []
    # import pdb
    # pdb.set_trace()
    for i in range(n):
        strList.append(s[i:])
    strList.sort()
    longestLen = 0
    for i in range(1, n):
        tmp = getLength(strList[i], strList[i-1])
        if tmp > longestLen:
            longestLen = tmp
            res = strList[i][:longestLen]
    return res

s = input()
print(getMaxCommonStr(s))