def quickSort(numList, first, end):
    if first > end:
        return
    high = end
    low = first
    key = numList[low]
    while low < high:
        while low < high and key < numList[high]:
            high -= 1
        numList[low]=numList[high]
        while low < high and key > numList[low]:
            low += 1
        numList[high] = numList[low]
    numList[low] = key
    quickSort(numList, first, low-1)
    quickSort(numList, high+1, end)
    return numList



#numList = [2,0,2,1,1,0]
numList = [2,3,9,8,5,6,1,7,0]
quickSort(numList, 0, len(numList)-1)
print(numList)