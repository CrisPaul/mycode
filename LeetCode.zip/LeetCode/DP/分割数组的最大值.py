tempDir = {}
def getSum(numList, end, start=0):
    sum = 0
    for i in range(start, end):
        sum += numList[i]
    return sum

def splitArray(nums, m):
    """
    :type nums: List[int]
    :type m: int
    :rtype: int
    """

    if m == 1:
        return getSum(nums, len(nums))
    import pdb
    pdb.set_trace()
    for i in range(len(nums)-1):
        #sumFirstPart, sumLastPart = 0, 0
        sumFirstPart = getSum(nums, i+1, 0)
        sumLastPart = getSum(nums, len(nums), i+1)
        tempDir[i] = max(sumFirstPart, sumLastPart)
    # import pdb
    # pdb.set_trace()
    minValue = tempDir[0]
    for k, v in tempDir.items():
        minValue = min(minValue, v)
    key = list(tempDir.keys())[list(tempDir.values()).index(minValue)]
    if tempDir[key] == getSum(nums, len(nums), key+1):
        return splitArray(nums[(key + 1):], m - 1)
    else:
        return splitArray(nums[:(key+1)], m - 1)

# nums = [7,2,5,10,8]
# n = 2
# nums = [2,3,1,2,4,3]
# n = 5
nums = [1,2147483647]
n = 2
print(splitArray(nums, n))

