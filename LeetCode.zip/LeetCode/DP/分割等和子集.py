def dfs(nums, target):
    if len(nums) == 0:
        return False
    if nums[-1] > target:
        return False
    for i in range(len(nums)):
        if nums[i]<target and dfs(nums[i+1:], target-nums[i]):
            return True
        if nums[i] == target:
            return True
    return False
def canPartition(nums):
    if sum(nums)%2==0:
        import pdb
        pdb.set_trace()
        target = sum(nums)//2
        nums.sort(reverse=True)
        if target < nums[0]:
            return False
        if target in nums:
            return True
        return dfs(nums, target)
    else:
        return False

nums = [3,5,13,3]
print(canPartition(nums))