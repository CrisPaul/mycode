class Solution:
    # def dfs(self, graph, colors, color, num):
    #     if colors[num] != -1:
    #         return color == colors[num]
    #     colors[num] = color
    #     for t in graph[num]:
    #         if not self.dfs(graph, colors, 1 - color, t):
    #             return False
    #     return True
    #
    # def isBipartite(self, graph: 'List[List[int]]') -> 'bool':
    #     size = len(graph)
    #     colors = [-1] * size
    #     for i in range(size):
    #         if colors[i] == -1 and self.dfs(graph, colors, 0, i) == False:
    #             return False
    #     return True
    def isBipartite(self, graph: 'List[List[int]]') -> 'bool':
        n = len(graph)
        if n == 1:
            return True
        from collections import defaultdict
        paths = defaultdict(set)
        colors = [-1] * n
        for i in range(n):
            for v in graph[i]:
                paths[i].add(v)
                paths[v].add(i)
        s = []

        colors[0] = 0
        s.append((0, colors[0]))
        # import pdb
        # pdb.set_trace()
        while s:
            node, color = s.pop(0)
            if len(paths[node]) == 0:
                s.append((node+1, 1-color))
                continue
            for elem in paths[node]:
                if colors[elem] == -1:
                    colors[elem] = 1 - colors[node]
                    s.append((elem, colors[elem]))
                else:
                    if colors[elem] == colors[node]:
                        return False
        return True

s = Solution()
#graph = [[1,2,3], [0,2], [0,1,3], [0,2]]
#graph = [[1,3], [0,2], [1,3], [0,2]]
graph = [[],[2,4,6],[1,4,8,9],[7,8],[1,2,8,9],[6,9],[1,5,7,8,9],[3,6,9],[2,3,4,6,9],[2,4,5,6,7,8]]
flag = s.isBipartite(graph)
print(flag)
