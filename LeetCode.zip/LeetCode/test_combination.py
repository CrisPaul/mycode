def combine(n, k):
    # n 表示 1...n
    # k表示k个数的组合，也就是矩阵的列数
    a = [0 * n]
    dp = []
    for i in range(1, k):
        a[i] = i

    for i in range(1, k-1):
        for j in range(i+1, k):
            dp[j]


