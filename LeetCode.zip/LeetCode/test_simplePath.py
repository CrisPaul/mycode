import re
def simplifyPath(path):
    """
    :type path: str
    :rtype: str
    """

    stackPathList = []
    rex = r'/{1,}'
    pathList = re.split(rex, path)
    for i in range(len(pathList)):
        if pathList[i] == '..':
            if stackPathList[-1] != '':
                stackPathList.pop()
            else:
                continue

        elif pathList[i] == '.':
            continue
        else:
            stackPathList.append(pathList[i])
    resStr = '/'.join(stackPathList)
    if resStr == '' or resStr == '/':
        return '/'
    else:
        return resStr.rstrip('/')


path = "/home/../../.."
print(simplifyPath(path))