# def climbStairs(n):
#     if n == 0 or n == 1:
#         return 1
#     else:
#         return climbStairs(n-1) + climbStairs(n-2)
#以上为递归算法 但是由于超出时间限制，所以可以采用以循环替代递归的方式来进行

def climbStairs(n):
    condition = [0] * (n+1)
    condition[0] = 1
    condition[1] = 1
    for i in range(2, n+1):
        condition[i] = condition[i-1] + condition[i-2]
    return condition[n]

numOfSteps = int(input())
print(climbStairs(numOfSteps))