# def adjustHeap(arr, i, size):
#     left = i*2 + 1
#     right = i*2 + 2
#     maxs = i
#     if i < size // 2:
#         if left < size and arr[left] > arr[maxs]:
#             maxs = left
#         if right < size and arr[right] > arr[maxs]:
#             maxs = right
#         if maxs != i:
#             arr[maxs], arr[i] = arr[i], arr[maxs]
#             adjustHeap(arr, maxs, size)
# def initHeap(arr, size):
#     for i in range(size//2)[::-1]:
#         adjustHeap(arr, i, size)
# def heapSort(arr):
#     size = len(arr)
#     initHeap(arr, size)
#     for i in range(size)[::-1]:
#         arr[0], arr[i] = arr[i], arr[0]
#         adjustHeap(arr, 0, i)
def adjustHeap(arr, num, size):
    left = num*2+1
    right = num*2+2
    maxV = num
    if maxV < size//2:
        if left < size and arr[left] > arr[maxV]:
            maxV = left
        if right < size and arr[right] > arr[maxV]:
            maxV = right
        if maxV != num:
            arr[num], arr[maxV] = arr[maxV], arr[num]
        adjustHeap(arr, maxV, size)


def initHeap(arr, size):
    for i in range(size//2)[::-1]:
        adjustHeap(arr, i, size)

def heapSort(arr):
    if len(arr) == 0:
        return
    size = len(arr)
    initHeap(arr, size)
    for i in range(size)[::-1]:
        arr[i], arr[0] = arr[0], arr[i]
        adjustHeap(arr, 0, i)

arr = [1,0,2,4,5,3,6]
heapSort(arr)
print(arr)