str = input()
lens = len(str)
i = 0
tmp = []
flagList = [0]*lens
import pdb
pdb.set_trace()
while i<lens:
    if str[i] == ')':
        if len(tmp) == 0:
            i += 1
            continue
        else:
            if i != lens-1 and len(tmp) == 1:
                tmp.pop(-1)
                flagList[index] = 0
            else:
                flagList[i] = 1
    elif str[i] >= '0' and str[i] <= '9' or str[i] == ',':
        flagList[i] = 1
    else:
        flagList[i] = 1
        index = i
        tmp.append(str[i])

    i += 1

sList = list(str)
for i in range(len(flagList)):
    if flagList[i] == 0:
        sList[i] = ''
print("".join(sList))