def combinationSum4(nums, target):
    """
    :type nums: List[int]
    :type target: int
    :rtype: int
    """
    #采用动态规划的思路来做
    dp = [0]*(target+1)
    n = len(nums)
    dp[0] = 1
    for i in range(1, target+1):
        for j in range(0, n):
            if nums[j] <= i:
                dp[i] += dp[i-nums[j]]

    return dp[target]

nums = [1,2,3]
target = 4
size = combinationSum4(nums, target)
print(size)