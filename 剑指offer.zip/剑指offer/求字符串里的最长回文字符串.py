def expandBothSide(s, left, right):
    n = len(s)
    if n == 0:
        return ""
    while left >= 0 and right < n and s[left] == s[right]:
        left -= 1
        right += 1
    return s[left+1:right]
def getLongestStr(str):
    if len(str) == 0:
        return ""
    if len(str) == 1:
        return str

    longestStr = ""
    for i in range(len(str)):
        tmp = expandBothSide(str, i, i)
        if len(tmp) > len(longestStr):
            longestStr = ''+tmp
        tmp = expandBothSide(str, i, i+1)
        if len(tmp) > len(longestStr):
            longestStr = '' + tmp

    return longestStr

if __name__ == '__main__':
    while True:
        try:
            s = input()
            result = getLongestStr(s)
            print(result)
        except:
            break
