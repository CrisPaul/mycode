class Solution:
    def findOrder(self, numCourses: 'int', prerequisites: 'List[List[int]]') -> 'List[int]':
        inDegree = [0] * numCourses
        from collections import defaultdict
        paths = defaultdict(set)

        for pre in prerequisites:
            paths[pre[1]].add(pre[0])
            inDegree[pre[0]] += 1
        s = []
        res = []
        for i in range(len(inDegree)):
            if inDegree[i] == 0:
                s.append(i)
                numCourses -= 1
                res.append(i)

        while s:
            node = s.pop(0)
            for elem in paths[node]:
                inDegree[elem] -= 1
                if inDegree[elem] == 0:
                    s.append(elem)
                    numCourses -= 1
                    res.append(elem)
        if numCourses != 0:
            return []
        else:
            return res
s = Solution()
#n, l = 2, [[1,0]]
n, l = 4, [[1,0],[2,0],[3,1],[3,2]]
print(s.findOrder(n, l))