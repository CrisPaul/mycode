def sort(left, right):
    n1, n2 = len(left), len(right)
    i = 0
    j = 0
    tmp = []
    while i < n1 and j < n2:
        if left[i] < right[j]:
            tmp.append(left[i])
            i += 1
        else:
            tmp.append(right[j])
            j += 1
    tmp += left[i:]
    tmp += right[j:]
    return tmp

def mergeSort(arr):
    if len(arr) == 1:
        return arr
    # import pdb
    # pdb.set_trace()
    mid = len(arr)//2
    left = mergeSort(arr[:mid])
    right = mergeSort(arr[mid:])
    return sort(left, right)

arr = [1,3,2,4,5,9,8,7,6]
print(mergeSort(arr))