import multiprocessing, threading
def func():
    x = 0
    while 1:
        x = x^1
for i in range(multiprocessing.cpu_count()):
    t = threading.Thread(target=func)
    t.start()

#print(multiprocessing.cpu_count())