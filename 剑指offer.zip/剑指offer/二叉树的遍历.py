class BinaryTreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

def constructTree(arr, start, end):
    if len(arr) == 1:
        return BinaryTreeNode(arr[0])
    if start > end or len(arr) == 0:
        return None

    mid = (start + end + 1)//2
    root = BinaryTreeNode(arr[mid])
    root.left = constructTree(arr, start, mid-1)
    root.right = constructTree(arr, mid+1, end)
    return root


#非递归前序遍历
def preVisitNode(root):
    p = root
    s = []
    while p != None or len(s) != 0:
        while p != None:
            s.append(p)
            print(p.val)
            p = p.left

        if len(s) != 0:
            p = s.pop()
            p = p.right

#非递归中序遍历
def midVisitNode(root):
    #p = BinaryTreeNode(0)
    p = root
    s = []
    while p != None or len(s) != 0:
        while p != None:
            s.append(p)
            p = p.left
        if len(s) != 0:
            p = s.pop()
            print(p.val)
            p = p.right
#递归后序遍历
def postOrderVisitRecursion(root):
    if root == None:
        return
    postOrderVisitRecursion(root.left)
    postOrderVisitRecursion(root.right)
    print(root.val)
#非递归后序遍历
def postOrderVisit(root):
    p = root
    s = []
    s.append(p)
    cur = None
    pre = None
    while len(s) != 0:
        cur = s[-1]
        if (cur.left == None and cur.right == None) \
            or (pre != None and (pre == cur.left or pre == cur.right)):
            print(cur.val)
            s.pop()
            pre = cur
        else:
            if cur.right != None:
                s.append(cur.right)
            if cur.left != None:
                s.append(cur.left)
#非递归后序遍历
def postVisitTree(root):
    if root == None:
        return
    s = []
    pre = None
    cur = None
    s.append(root)
    while len(s) != 0:
        tmp = s[-1]
        cur = tmp
        if (cur.left == None and cur.right == None) \
            or (pre != None and (pre == cur.left or pre == cur.right)):
            print(cur.val)
            s.pop()
            pre = cur
        else:
            if cur.right != None:
                s.append(cur.right)
            if cur.left != None:
                s.append(cur.left)


def levelVisit(root):
    if root == None:
        return
    resList = []
    q = []
    q.append(root)
    while len(q) != 0:
        tmpList = []
        n = len(q)
        # import pdb
        # pdb.set_trace()
        for i in range(n):
            tmp = q.pop(0)
            tmpList.append(tmp.val)
            if tmp.left != None:
                q.append(tmp.left)
            if tmp.right != None:
                q.append(tmp.right)
        resList.append(tmpList)
    return resList

def isAbsoluteBinaryTree(root):
    if root == None:
        return
    r = root
    resList = []
    q = []
    q.append(r)
    flag = True
    while len(q) != 0:
        tmpList = []
        n = len(q)
        for i in range(n):
            tmp = q.pop(0)
            tmpList.append(tmp.val)
            if tmp.left != None:
                if flag == False:
                    return False
                q.append(tmp.left)
            else:
                flag = False
            if tmp.right != None:
                if flag == False:
                    return False
                q.append(tmp.right)
            else:
                flag = False
        resList.append(tmpList)





array = [1,2,3,4,5,6,7,8]
root = constructTree(array, 0, len(array)-1)
#preVisitNode(root)
print("------------------")
#midVisitNode(root)
#postOrderVisit(root)
#postVisitTree(root)
#postOrderVisitRecursion(root)
print(levelVisit(root))
if isAbsoluteBinaryTree(root):
    print('yes')
else:
    print('true')