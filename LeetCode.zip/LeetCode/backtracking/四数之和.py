class Solution:
    def fourSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[List[int]]
        """
        #字典查找法
        size = len(nums)
        dic = {}
        res = []
        for i in range(size-1):
            for j in range(i+1, size):
                sumOf1stTwoNums = nums[i]+nums[j]
                if sumOf1stTwoNums not in dic:
                    dic[sumOf1stTwoNums] = [(i, j)]
                else:
                    dic[sumOf1stTwoNums].append((i, j))
        for i in range(2, size-1):
            for j in range(i+1, size):
                k = target - nums[i] - nums[j]
                if k in dic:
                    for v in dic[k]:
                        if v[1] < i:
                            res.add((nums[v[0]], nums[v[1]], nums[i], nums[j]))
        return [list(x) for x in res]
