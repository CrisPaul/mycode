class Solution:
    def findRedundantConnection(self, edges: 'List[List[int]]') -> 'List[int]':
        parents = list(range(len(edges) + 1))

        def find(x):
            if x != parents[x]:
                parents[x] = find(parents[x])
            return parents[x]

        for edge in edges:
            i, j = find(edge[0]), find(edge[1])
            if i == j:
                return edge

            parents[i] = j
        return []

list1 = [[1,2], [1,3], [2,3]]
list2 = [[1,2], [2,3], [3,4], [1,4], [1,5]]
s = Solution()
print(s.findRedundantConnection(list2))