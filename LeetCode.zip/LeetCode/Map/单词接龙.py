class Solution:
    # def ladderLength(self, beginWord: 'str', endWord: 'str', wordList: 'List[str]') -> 'int':
    #     wordDict = set(wordList)
    #     if endWord not in wordDict:
    #         return 0
    #     if beginWord in wordDict:
    #         wordDict.remove(beginWord)
    #
    #     stack, visited = [(beginWord, 1)], set()
    #     while stack:
    #         word, step = stack.pop(0)
    #         if word not in visited:
    #             visited.add(word)
    #             if word == endWord:
    #                 return step
    #             for i in range(len(word)):
    #                 for j in 'abcdefghijklmnopqrstuvwxyz':
    #                     tmp = word[:i] + j + word[i + 1:]
    #                     if tmp in wordDict and tmp not in visited:
    #                         stack.append((tmp, step + 1))
    #
    #     return 0
    def ladderLength(self, beginWord: 'str', endWord: 'str', wordList: 'List[str]') -> 'int':
        wordDic = set(wordList)
        if endWord not in wordDic:
            return 0
        if beginWord in wordDic:
            wordDic.remove(beginWord)
        # import pdb
        # pdb.set_trace()
        tmpList = [(beginWord, 1)]
        visited = set()
        s = "abcdefghijklmnopqrstuvwxyz"
        while tmpList:
            tmp = tmpList.pop(0)
            word, step = tmp[0], tmp[1]
            if word not in visited:
                visited.add(word)
                if word == endWord:
                    return step
                for i in range(len(word)):
                    for j in s:
                       string = word[:i] + j + word[i+1:]
                       if string in wordDic and string not in visited:
                           tmpList.append((string, step + 1))
        return 0

s = Solution()
beginWord = "hit"
endWord = "cog"
wordList = ["hot","dot","dog","lot","log","cog"]
n = s.ladderLength(beginWord, endWord, wordList)
print(n)

