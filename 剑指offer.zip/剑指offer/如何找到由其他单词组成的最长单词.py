def findWordInArr(str, arr):
    if str in arr:
        return True
    n = len(str)
    for i in range(1, n):
        if str[:i] in arr and findWordInArr(str[i:], arr):
            return True
    return False

s = "ttestpack"

#arr = ["t", "tes", "test", "pack"]
arr = ["t", "tee", "te", "stp", "test", "ac", "pack"]
if findWordInArr(s, arr):
    print('yes')
else:
    print('false')
