class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

def reverseTree(self, root):
    if root == None:
        return
    reverseTree(root.left)
    reverseTree(root.right)
    root.left, root.right = root.right, root.left

def isSymmetric(self, root):
    if


def arrayToTree(arr, start, end):
    root = None
    if end >= start:
        if start+end >= 2:
            mid = (start + end) // 2
        else:
            mid = 0
        root = TreeNode(arr[mid])
        if mid >= 1:
            root.left = arrayToTree(arr, start, mid-1)
        else:
            root.left = None
        root.right = arrayToTree(arr, mid+1, end)
    else:
        root = None
    return root