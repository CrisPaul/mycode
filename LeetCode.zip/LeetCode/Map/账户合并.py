class Solution:

    def accountsMerge(self, accounts):
        """
        :type accounts: List[List[str]]
        :rtype: List[List[str]]
        """
        mailDic = {}

        for ct, i in enumerate(accounts):
            for j in i[1:]:
                mailDic[j] = (ct, i[0])
        import pdb
        pdb.set_trace()
        mails = {mail: idx for idx, mail in enumerate(mailDic.keys())}
        mailNum = len(mails)
        self.findSet = [i for i in range(mailNum)]
        for li in accounts:
            n = len(li)
            for i in range(1, n - 1):
                for j in range(i + 1, n):
                    self.union(mails[li[i]], mails[li[j]])
        dic = {}
        mails = {j: i for i, j in mails.items()}
        for i in range(mailNum):
            mail = mails[i]
            n = mailDic[mails[self.find(i)]][0]
            if n in dic:
                dic[n].append(mail)
            else:
                dic[n] = [mail]
        nameId = {i[0]: i[1] for i in mailDic.values()}
        return [[nameId[i]] + sorted(mail) for i, mail in dic.items()]

    def find(self, i):
        if self.findSet[i] != i:
            n = self.find(self.findSet[i])
            self.findSet[i] = n
        return self.findSet[i]

    def union(self, i, j):
        if i != j:
            n = self.find(i)
            if n != self.find(j):
                self.findSet[n] = self.findSet[j]
a = Solution()
accounts = [
    ["John", "johnsmith@mail.com", "john00@mail.com"],
    ["John", "johnnybravo@mail.com"],
    ["John", "johnsmith@mail.com", "john_newyork@mail.com"],
    ["Mary", "mary@mail.com"]
    ]
print(a.accountsMerge(accounts))
