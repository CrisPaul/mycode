class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

    def validBST(self, root, low, high):
        if root is None:
            return True
        if root.val < low or root.val > high:
            return False
        return self.validBST(root.left, low, root.val) and self.validBST(root.right, root.val, high)

    def isValidBST(self, root):
        return self.validBST(root, -2**32, 2**32-1)


