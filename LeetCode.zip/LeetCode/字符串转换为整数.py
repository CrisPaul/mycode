class Solution:
    def myAtoi(self, str: 'str') -> 'int':
        coll = ''
        str = str.strip()
        t = len(str)

        for i in range(t):
            # 是数字吗？
            if str[i] >= '0' and str[i] <= '9':
                coll += str[i]
                if i == t - 1 or str[i + 1] < '0' or str[i + 1] > '9':
                    out = int(coll)
                    if out < -2 ** 31:
                        return -2 ** 31
                    elif out > 2 ** 31 - 1:
                        return 2 ** 31 - 1
                    else:
                        return int(out)
            # 是正号或负号吗？
            elif str[i] == '-' or str[i] == '+':
                if i < t - 1 and str[i + 1] >= '0' and str[i + 1] <= '9':
                    coll += str[i]
                else:
                    return 0
            else:
                return 0
        return 0
