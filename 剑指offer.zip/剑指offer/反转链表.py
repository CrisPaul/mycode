# class ListNode:
#     def __init__(self, x):
#         self.data = x
#         self.next = None
# class List:
#     def __init__(self):
#         self.head = ListNode(0)
#         self.next = None
#     def constructList(self, arr):
#         cur = self.head
#         for elem in arr:
#             tmp = ListNode(elem)
#             cur.next = tmp
#             cur = tmp
#         return self.head
#     def reversed(self, head):
#         if head == None or head.next == None:
#             return head
#         cur = head.next.next
#         head.next.next = None
#         while cur!= None:
#             pNext = cur.next
#             #cur.next = None
#             cur.next = head.next
#             head.next = cur
#             cur = pNext
#         return head
#     def printList(self,head):
#         if head == None or head.next == None:
#             return None
#
#         cur = head.next
#         while cur != None:
#             print(cur.data)
#             cur = cur.next
class ListNode:
    def __init__(self, x):
        self.data = x
        self.next = None

class List:
    def __init__(self):
        self.head = ListNode(0)
        self.next = None
    def constructList(self, arr):
        cur = self.head
        for i in range(len(arr)):
            cur.next = ListNode(arr[i])
            cur = cur.next
        return self.head
    def reversedList(self, head):
        if head == None or head.next == None:
            return head
        cur = head.next.next
        head.next.next = None
        while cur != None:
            pNext = cur.next
            cur.next = head.next
            head.next = cur
            cur = pNext
        return head
    def printList(self, head):
        if head == None or head.next == None:
            return
        cur = head.next
        while cur != None:
            print(cur.data)
            cur = cur.next
arr = [1,2,3,4,5,6]
l = List()
head = l.constructList(arr)
head1 = l.reversedList(head)
l.printList(head)
print("######## After reversed #############")
l.printList(head1)

#h1 = l.reversed(head)
#l.printList(h1)