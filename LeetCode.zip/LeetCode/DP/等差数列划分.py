

def isArithmeticProgression(A, n=3):
    flag = True
    # import pdb
    # pdb.set_trace()
    for i in range(1, n - 1):
        if A[i] - A[i - 1] == A[i + 1] - A[i]:
            continue
        else:
            flag = False
            break
    return flag


def numberOfArithmeticSlices(A):
    """
    :type A: List[int]
    :rtype: int
    """
    if len(A) < 3:
        return 0
    if len(A) == 3:
        if isArithmeticProgression(A):
            return 1
        else:
            return 0
    counter = 0
    n = 3
    while n <= len(A) and isArithmeticProgression(A, n):
        counter += 1
        n += 1
    return numberOfArithmeticSlices(A[1:]) + counter
    #return sum

a = [1,2,3,8,9,10]
b=[1,2,3,4]
print(numberOfArithmeticSlices(b))