'''
- 冒泡排序
- 时间复杂度：O(n^2)
- 空间复杂度：O(1)
'''

def bubbleSort(arr):
    for i in range(1, len(arr)):
        for j in range(len(arr)-i):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr

arr = [1,3,2,5,4,6,7]
print(bubbleSort(arr))
