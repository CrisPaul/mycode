def swap(s, x1, x2):
    s[x1], s[x2] = s[x2], s[x1]
def getAllOrderList(s):
    #head = s[0]

    if len(s) == 1:
        return s[0]
    tmp = []
    for i in range(len(s)):
        swap(s, 0, i)
        res = getAllOrderList(s[1:])
        for elem in res:
            tmp.append(''.join(s[0] + elem))
        swap(s, 0, i)
    return tmp
#tmp = ""
s = "abcdefg"
result = getAllOrderList(list(s))
print(result)