#利用拓扑排序来做
#解题思路：
# # 1. 计算图中所有节点的入度
# # 2. 删除入度为0的节点，该节点指向的连接节点对应的入度减1
# # 3. 重复2操作，循环。 直到没有入度为0 的节点为止
# # 4. 判断，假如没有入度为0的节点同时没有剩余的节点，即所有的节点都被删除，那么说明该图没有环，返回True
# # 5. 否则， 假如存在有剩余的节点，且该节点的入度不为0， 那么说明该图有环，返回false

class Solution:

    def canFinish(self, numCourses: 'int', prerequisites: 'List[List[int]]') -> 'bool':

        from collections import defaultdict
        paths = defaultdict(set)
        s = []
        inDegree = [0 for _ in range(numCourses)]

        # 构建入度
        for pre in prerequisites:
            inDegree[pre[0]] += 1
            paths[pre[1]].add(pre[0])

        # 将入度为0 的节点存入到s中
        for i in range(len(inDegree)):
            if inDegree[i] == 0:
                s.append(i)
                numCourses -= 1
        while s:
            node = s.pop()
            for k in paths[node]:
                inDegree[k] -= 1
                if inDegree[k] == 0:
                    s.append(k)
                    numCourses -= 1

        return (numCourses == 0)







