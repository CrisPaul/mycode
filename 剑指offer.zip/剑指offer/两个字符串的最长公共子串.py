def getLongestSubStr(s1, s2):
    if s1 == "" or s2 == "":
        return
    len1, len2 = len(s1), len(s2)
    maxLen = 0
    counter = 0
    resList = []
    tmp = ""
    position = 0
    dp = [[0 for i in range(len1+1)] for j in range(len2+1)]
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            if s1[i-1] == s2[j-1]:
                #counter += 1
                dp[i][j] = dp[i-1][j-1] + 1
                if dp[i][j] > maxLen:
                    maxLen = dp[i][j]
                    position = i
            else:
                dp[i][j] = 0
    index = position - maxLen
    while index < position:
        tmp += s1[index]
        index += 1
    return tmp

str1 = "abccade"
str2 = "dgcadde"
print(getLongestSubStr(str1, str2))
