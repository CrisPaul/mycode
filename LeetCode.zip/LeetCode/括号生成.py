def dfs(left, right, s, res):
    import pdb
    pdb.set_trace()
    if left == 0 and right == 0:
        res.append(s)
    else:
        if left > 0:
            dfs(left-1, right, s+'(', res)
        if left < right:
            dfs(left, right-1, s+')', res)
def generateParenthesis(n):
    s = ''
    # import pdb
    # pdb.set_trace()
    res = []
    dfs(n, n, s, res)
    return  res

resultList = generateParenthesis(3)
for elem in resultList:
    print(elem)
