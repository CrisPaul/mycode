def insertElem(firstSubList, c):
    if c <= firstSubList[0]:
        firstSubList.inset(0, c)
    if c >= firstSubList[-1]:
        firstSubList.append(c)
    for i in range(1, len(firstSubList)):
        if (firstSubList[i] >= c and firstSubList[i-1] < c) or (firstSubList[i] > c and firstSubList[i-1] <= c):
            firstSubList.insert(i, c)
            break

def insertSort(aList):
    if len(aList)==0:
        return
    i = 1
    n = len(aList)
    # import pdb
    # pdb.set_trace()
    for i in range(1, len(aList)):
        for j in range(0, i):
            if aList[i] < aList[j]:
                tmp = aList[i]
                aList.pop(i)
                aList.insert(j, tmp)
    print(aList) #aList



aList = [38,65,97,76,13,27,49]
insertSort(aList)
# print(res)
