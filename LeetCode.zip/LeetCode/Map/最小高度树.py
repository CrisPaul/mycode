class Solution:
    def findMinHeightTrees(self, n: 'int', edges: 'List[List[int]]') -> 'List[int]':
        # if n == 1:
        #     return [0]
        # paths = [set() for _ in range(n)]
        # for edge in edges:
        #     paths[edge[0]].add(edge[1])
        #     paths[edge[1]].add(edge[0])
        # leaves = [ node for node in range(n) if len(paths[node]) == 1]
        # num  = n
        # while num > 2:
        #     num -= len(leaves)
        #     newleaves = []
        #     for node in leaves:
        #         parent = paths[node].pop()
        #         paths[parent].remove(node)
        #         if len(paths[parent]) == 1:
        #             newleaves.append(parent)
        #     leaves = newleaves
        # return leaves

        if n == 1:
            return [0]
        paths = [set() for _ in range(n)]
        for edge in edges:
            paths[edge[0]].add(edge[1])
            paths[edge[1]].add(edge[0])
        leaves = [node for node in range(n) if len(paths[node]) == 1]
        num = n
        while num > 2:
            num -= len(leaves)
            newleaves = []
            for node in leaves:
                parent = paths[node].pop()
                paths[parent].remove(node)

                if len(paths[parent]) == 1:
                    newleaves.append(parent)
            leaves = newleaves
        return leaves
s = Solution()
n = 6
edges = [[0, 3], [1, 3], [2, 3], [4, 3], [5, 4]]
print(s.findMinHeightTrees(n, edges))