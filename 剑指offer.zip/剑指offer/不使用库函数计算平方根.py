def squareRoot(n, e):
    new_one = n
    last_one = 1.0
    import pdb
    pdb.set_trace()
    while new_one - last_one > e:
        new_one = (new_one + last_one) //2
        last_one = n // new_one
    return new_one
n = 50
e = 0.00000001
print(squareRoot(n, e))