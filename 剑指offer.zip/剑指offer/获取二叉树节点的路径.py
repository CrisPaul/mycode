def getPath(root, p, resList):
    if root == None:
        return
    if root == p:
        resList.append(root.val)
