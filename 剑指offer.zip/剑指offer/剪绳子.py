def getMaxLength(length):
    if length < 2:
        return 0
    if length == 2:
        return 1
    if length == 3:
        return 2

    products = []
    products += [0,1,2,3]
    max = 0
    for i in range(length+1):
        max = 0
        for j in range(i//2 + 1):
            product = products[j] * products[i-j]
            if max < product:
                max = product
            products[i] = max
    max = products[length]
    return max