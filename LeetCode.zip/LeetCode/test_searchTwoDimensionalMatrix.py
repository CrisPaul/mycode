def searchMatrix(matrix, target):
    rowIndexList = []
    rowNum = 0
    # import pdb
    # pdb.set_trace()
    if len(matrix)==0 or len(matrix[0])==0:
        return False
    for i in range(len(matrix)):
        num = matrix[i][0]
        rowIndexList.append(num)
    for k, v in list(enumerate(rowIndexList)):
        if target < v and k == 0:
            return False
        elif target < v:
            rowNum = k
            break
    for elem in matrix[rowNum-1]:
        if elem == target:
            return True
    return False

# matrix = [
#   [1,   3,  5,  7],
#   [10, 11, 16, 20],
#   [23, 30, 34, 50]
# ]
# t = 3

matrix = [
  [1,   3,  5,  7],
  [10, 11, 16, 20],
  [23, 30, 34, 50]
]
t = 13
# matrix = []
# t=0
flag = searchMatrix(matrix, t)
if flag:
    print('true')
else:
    print('false')

