def longestBracket(s):
    sLength = len(s)
    dp = [0]*sLength
    for i in range(sLength):
        if s[i] == '(':
            dp[i] = 0
        else:
            if i == 0:
                dp[i] = 0
            elif s[i-1] == ')' and s[i-dp[i-1]-1] == '(' and i-dp[i-1]-1 >= 0:
                if i-dp[i-1]-1 == 0:
                    dp[i] = dp[i-1] + 2
                if i-dp[i-1]-1 > 0:
                    dp[i] = dp[i-1] + 2 + dp[i-dp[i-1]-2]
            elif s[i-1] == '(' :
                if i >= 2:
                    dp[i] = dp[i-2] + 2
                else:
                    dp[i] = 2

    return max(dp)

#s = ')()())'
s = '()()'
#s = ')('
print(longestBracket(s))



