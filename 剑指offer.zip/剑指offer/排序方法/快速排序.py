def quickSort(arr, begin, end):
    if len(arr) == 0 or begin > end:
        return
    left = begin
    right = end
    key = arr[left]
    while left < right:
        while left < right and arr[right] >= key:
            right -= 1
        arr[left] = arr[right]
        while left < right and arr[left] <= key:
            left += 1
        arr[right] = arr[left]
    arr[left] = key
    quickSort(arr, begin, left-1)
    quickSort(arr, left+1, end)

arr = [1,3,5,7,2,4,6]
quickSort(arr,0,len(arr)-1)
print(arr)



