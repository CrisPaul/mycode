class ListNode:
    def __init__(self,x):
        self.val = x
        self.next = None
class List:
    def constructList(self, arr):
        # import pdb
        # pdb.set_trace()
        head = ListNode(0)
        head.next = None
        pre = head
        for elem in arr:
            node = ListNode(elem)
            pre.next = node
            pre = node
        return head

    def printList(self, head):
        cur = head.next
        while cur != None:
            print(cur.val)
            cur = cur.next
    def findKthTailNode(self, k, head):
        if k == 0 or head == None:
            return None
        pFast = head
        #pLow = None
        for i in range(k-1):
            pFast = pFast.next
        pLow = head
        while pFast.next != None:
            pLow = pLow.nex
            pFast = pFast.next

        return pLow

array = [1,2,3,5,4,6]
l = List()
pHead = l.constructList(array)
l.printList(pHead)
res = l.findKthTailNode(3, pHead)
print(res.val)