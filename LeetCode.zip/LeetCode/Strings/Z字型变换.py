def zTransforms(s, numRows):
    n = len(s)
    m = 2*numRows -2
    for i in range(n):
        if (i+1) % m == numRows:




