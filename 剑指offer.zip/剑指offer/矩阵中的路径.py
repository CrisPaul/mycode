#def hasPath(matrix, rows, cols, str):
def findPath(matrix, rows, cols, row, col, s, path, visited):
    if len(s) == 0:
        return True
    # import pdb
    # pdb.set_trace()
    #visited[row][col] = 1
    hasPath = False
    if row >= 0 and row < rows and col >= 0 and col < cols and matrix[row][col] == s[0] and visited[row][col] == 0:
        path.append((row, col))
        visited[row][col] = True

        hasPath = findPath(matrix, rows, cols, row, col-1, s[1:], path, visited) \
                  or findPath(matrix, rows, cols, row, col+1, s[1:], path, visited) \
                  or findPath(matrix, rows, cols, row+1, col, s[1:], path, visited) \
                  or findPath(matrix, rows, cols, row-1, col, s[1:], path, visited)
        if not hasPath:
            path.pop(-1)
            visited[row][col] = False
    return hasPath

m, n = map(int, input().split())
visited = [[ False for i in range(n)] for j in range(m)]
matrix = [
    ['a', 'b', 't', 'g'],
    ['c', 'f', 'c', 's'],
    ['j', 'd', 'e', 'h']
]
s = "bfce"
path = []
for i in range(len(matrix)):
    for j in range(len(matrix[0])):
        #从任意位置开始
        if findPath(matrix, len(matrix), len(matrix[0]), i, j, s, path, visited):
            print('true', path)

        else:
            print('false')