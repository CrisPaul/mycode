def getLongestIncreSubque(arr):
    if len(arr) == 0:
        return 0
    import pdb
    pdb.set_trace()
    maxLen = 1
    dp = [ 1 for i in range(len(arr)+1)]
    for i in range(1, len(arr)):
        for j in range(i):
            if arr[i] > arr[j] and dp[j] > dp[i]-1:
                dp[i] = dp[j] + 1
                if dp[i] > maxLen:
                    maxLen = dp[i]
    return maxLen

arr = "xabcqd"
arr2 = ""
arr3 = "aabcda"
arr4 = "dc&a05"
length = getLongestIncreSubque(list(arr3))
print(length)