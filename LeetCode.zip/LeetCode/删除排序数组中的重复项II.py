def removeDuplicates(nums):
    i = 0
    cnt = 1
    # i用来扫描
    while i < len(nums):
        while i < len(nums) - 1 and cnt < 2 and nums[i] == nums[i + 1]:  # 注意，当cnt超过2时这个循环就会跳出
            i += 1
            cnt += 1
        while i < len(nums) - 1 and nums[i] == nums[i + 1]:  # 删除cnt超过2的数字
            del nums[i + 1]
        cnt = 1
        i += 1

#nums = [0,0,1,1,1,1,2,3,3]
#nums = [-3,-1,0,0,0,3,3]
nums = [1,1,1,2,2,3]
print(removeDuplicates(nums))
