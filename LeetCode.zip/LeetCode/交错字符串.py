def isInterleave(s1, s2, s3):
    len1, len2, len3 = len(s1), len(s2), len(s3)
    if len1+len2 != len3:
        return False
    # import pdb
    # pdb.set_trace()
    dp = [[ False for j in range(len2+1)] for i in range(len1+1)]
    dp[0][0] = True
    for i in range(1, len1+1):
        if dp[i-1][0] and s1[i-1]==s3[i-1]:
            dp[i][0] = True
    for j in range(1, len2+1):
        if dp[0][j-1] and s2[j-1]==s3[j-1]:
            dp[0][j] = True
    for i in range(1, len1+1):
        for j in range(1, len2+1):
            dp[i][j] = (dp[i-1][j] and s1[i-1]==s3[i+j-1]) or (dp[i][j-1] and s2[j-1]==s3[i+j-1])

    return dp[len1][len2]


s1 = "aabcc"
s2 = "dbbca"
s3 = "aadbbcbcac"
s4 = "aadbbbaccc"
print(isInterleave(s1, s2, s3))
print(isInterleave(s1, s2, s4))
