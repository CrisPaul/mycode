def bin_search(arr, value):
    n = len(arr)
    begin = 0
    end = n-1
    while begin <= end:
        mid = (begin + end)//2
        if arr[mid] == value:
            return mid
        elif arr[mid] < value:
            begin = mid+1
        else:
            end = mid-1
    return

def bin_search(arr, val):
    n = len(arr)
    begin = 0
    end = n-1
    while begin <= end:
        mid = (begin + end) // 2
        if arr[mid] == val:
            return mid
        elif arr[mid] < val:
            begin = mid + 1
        else:
            end = mid - 1
    return
arr = [1,3,5,7,9]
pos = bin_search(arr, 5)
print(pos)