class Solution:
    def canVisitAllRooms(self, rooms: 'List[List[int]]') -> 'bool':
        n = len(rooms)
        mark = [0 for _ in range(n)]
        mark[0] = 1
        s = [0]
        while len(s):
            tmp = s.pop()
            for room_key in rooms[tmp]:
                if mark[room_key] == 0:
                    s.append(room_key)
                    mark[room_key] = 1
        if len(s) == n:
            return True
        else:
            return False

s = Solution()
l1 = [[1,3],[3,0,1],[2],[0]]

if s.canVisitAllRooms(l1):
    print('yes')
else:
    print('no')