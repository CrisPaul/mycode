# def bubbleSort(nums):
#     length = len(nums)
#     if length == 0:
#         return
#     for i in range(len(nums)-1):
#         for j in range(len(nums)-i-1):
#             if nums[j] > nums[j+1]:
#                 nums[j], nums[j+1] = nums[j+1], nums[j]
#     return nums
def bubbleSort(nums):
    lenNum = len(nums)
    if lenNum == 0:
        return nums
    for i in range(len(nums)-1):
        for j in range(len(nums)-i-1):
            if nums[j] > nums[j+1]:
                nums[j], nums[j+1] = nums[j+1], nums[j]
    return nums
numsList = [2,0,2,1,1,0]
print(bubbleSort(numsList))