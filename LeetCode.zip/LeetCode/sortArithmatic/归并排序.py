# def merge(left, right):
#     # import pdb
#     # pdb.set_trace()
#     i, j = 0, 0
#     result = []
#     while i < len(left) and j < len(right):
#         if left[i] <= right[j]:
#             result.append(left[i])
#             i += 1
#         else:
#             result.append(right[j])
#             j += 1
#     result += left[i:]
#     result += right[j:]
#     return result
# def mergeSort(aList):
#     if len(aList) <= 1:
#         return aList
#     num = len(aList) // 2
#     left = mergeSort(aList[:num])
#     right = mergeSort(aList[num:])
#     return merge(left, right)
def merge(left, right):
    len1, len2 = len(left), len(right)
    i, j = 0, 0
    res = []
    while i < len1 and j < len2:
        if left[i] < right[j]:
            res.append(left[i])
            i += 1
        else:
            res.append(right[j])
            j += 1
    res += left[i:]
    res += right[j:]
    return res

def mergeSort(aList):
    if len(aList) == 1:
        return aList
    mid = len(aList) // 2
    left = mergeSort(aList[:mid])
    right = mergeSort(aList[mid:])
    return merge(left, right)
aList = [1,3,5,2,6,9,8,0,7,4]
print(mergeSort(aList))
