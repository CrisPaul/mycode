def countNumbersWithUniqueDigits(n):
    """
    :type n: int
    :rtype: int
    """
    if n == 1:
        return 10
    if n == 0:
        return 1
    f = 9
    res = 10
    if n >= 2:
        for i in range(2, n+1):
            f *= (10 - i + 1)
            res += f
    return res


result = countNumbersWithUniqueDigits(2)
print(result)
