'''
paul.wang
01-12-2019
'''
def func(arr):
    if len(arr) == 0:
        return
    tmpList = []
    for i in range(len(arr)):
        lens = len(tmpList)
        if lens == 0:
            tmpList.append(arr[i])
            continue
        for j in range(lens):
            tmpList.append(tmpList[j] + arr[i])
        tmpList.append(arr[i])
    return tmpList
arr = ['a', 'b', 'c', 'd']
arr1 = ['a','b','c']
print(func(arr1))
