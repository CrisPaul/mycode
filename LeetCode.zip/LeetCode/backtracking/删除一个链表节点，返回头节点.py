# Definition for singly-linked list.
class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None

class Solution:
    def removeNthFromEnd(self, head, n):
        """
        :type head: ListNode
        :type n: int
        :rtype: ListNode
        """
        res = ListNode(0)
        res.next = head
        l1 = res
        l2 = res
        for i in range(n):
            l1 = l1.next
        while l1.next:
            l1 = l1.next
            l2 = l2.next
        l2.next = l2.next.next
        return res.next

ListNode()