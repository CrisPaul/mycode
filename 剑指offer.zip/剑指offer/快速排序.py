def quickSort(arr, start, end):
    if len(arr) == 0 or end < start:
        return
    base = arr[start]
    low = start
    high = end
    while low < high:
        while low < high and base < arr[high]:
            high -= 1
        arr[low] = arr[high]
        while low < high and base > arr[low]:
            low += 1
        arr[high] = arr[low]
    arr[low] = base
    quickSort(arr, start, low-1)
    quickSort(arr, low+1, end)

arr = [1,3,4,8,7,6,9,5,2]
quickSort(arr, 0, len(arr)-1)
print(arr)
