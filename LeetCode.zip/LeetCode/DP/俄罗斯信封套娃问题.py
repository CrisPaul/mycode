# def findIndex(env, n):
#     index = 0
#     for i in range(n):
#         if env[n-1-i][1] - env[n][1] < 0:
#             index = i
#             break
#     return index
#
#
#
# def maxEnvelopes(envelopes):
#     """
#     :type envelopes: List[List[int]]
#     :rtype: int
#     """
#     n = len(envelopes)
#     envelopes = sorted(envelopes, key=lambda x: x[0])
#     dp = [0]*(n+1)
#     import pdb
#     pdb.set_trace()
#     for i in range(1, n):
#         if envelopes[i][1] > envelopes[i-1][1]:
#             dp[i] = dp[i-1] + 1
#         else:
#             j = findIndex(envelopes, i)
#             dp[i] = max(dp[i-1], dp[j]+1)
#
#     return dp[n]

def maxEnvelopes(envelopes):
    """
    :type envelopes: List[List[int]]
    :rtype: int
    """
    res = 0
    n = len(envelopes)
    envelopes.sort()
    import pdb
    pdb.set_trace()
    dp = [1] * n
    for i in range(n):
        if envelopes[i][0] > envelopes[j][0] and envelopes[i][1] > envelopes[j][1]:
            dp[i] = max(dp[i], dp[j]+1)
        # for j in range(i):
        #     if envelopes[i][0] > envelopes[j][0] and envelopes[i][1] > envelopes[j][1]:
        #         dp[i] = max(dp[i], dp[j] + 1)
        res = max(dp[i], res)
    return res

envelopes = [[5,4],[6,4],[6,7],[2,3]]
num = maxEnvelopes(envelopes)
print(num)
