def LNode:
    def __new__(self, x):
        self.data = x
        self.next = None

def RotateK(head, k):
    if head == None or head.next == None:
        return
    slow, fast, tmp = LNode(), LNode(), LNode()
    slow, fast = head.next, head.next
    i = 0
    while i < k and fast != None:
        fast = fast.next
        i += 1

    while fast.next != None:
        slow = slow.next
        fast = fast.next
    tmp = slow
    slow = slow.next
    fast = fast.next
    tmp.next = None
    fast.next=head.next
    head.next = slow