class TreeNode:
    def __init__(self, x):
        self.data = x
        self.left = None
        self.right = None

class Test:
    def __init__(self):
        self.pStart = None
        self.pEnd = None

    def arrToTree(self, arr, start, end):
        if start > end:
            return
        if len(arr) == 1:
            return self.arrToTree(arr[0])
        mid = (start + end + 1) // 2
        root = TreeNode(arr[mid])
        root.left = self.arrToTree(arr, start, mid-1)
        root.right = self.arrToTree(arr, mid+1, end)
        return root

    def levelVisit(self, root):
        if root == None:
            return
        resList = []
        q = []
        q.append(root)
        while len(q) != 0:
            tmpList = []
            n = len(q)
            # import pdb
            # pdb.set_trace()
            for i in range(n):
                tmp = q.pop(0)
                tmpList.append(tmp.data)
                if tmp.left != None:
                    q.append(tmp.left)
                if tmp.right != None:
                    q.append(tmp.right)
            resList.append(tmpList)
        return resList
    def treeToList(self, root):
        if root == None:
            return
        cur = root
        if cur.left != None:
            self.treeToList(cur.left)
        # import pdb
        # pdb.set_trace()
        # cur.left = self.pEnd
        # if self.pEnd == None:
        #     self.pStart = cur
        # else:
        #     self.pEnd.right = cur
        # self.pEnd = cur
        if self.pStart == None:
            self.pStart = root
            self.pEnd = root
        else:
            root.left = self.pEnd
            self.pEnd.right = root
            self.pEnd = root
        if cur.right != None:
            self.treeToList(cur.right)
    def printList(self):
        p = self.pStart
        print("From head node to end.")
        # import pdb
        # pdb.set_trace()
        while p != None:
            print(p.data)
            p = p.right
        print("From last node to head.")
        p = self.pEnd
        while p != None:
            print(p.data)
            p = p.left


t = Test()
array = [1,2,3,4,5,6,7,8]
root = t.arrToTree(array, 0, len(array)-1)
print(root.data)
print(t.levelVisit(root))
t.treeToList(root)
t.printList()