def isSubsequence(s, t):
    """
    :type s: str
    :type t: str
    :rtype: bool
    """
    #t = list(t)
    flag = 1
    for i in range(len(s)):
        index = t.find(s[i])
        if index >= 0:
            t = '' + t[index+1:]

        else:
            flag = 0
            break
    if flag:
        return True
    else:
        return False

s = "abc"
t = "ahbgdc"
s1 = "axc"
t1 = "ahbgdc"
print(isSubsequence(s1, t1))