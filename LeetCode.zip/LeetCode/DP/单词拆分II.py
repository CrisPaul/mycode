def backTrack(s, wordDict, subStrList, result, index):
    n = len(s)
    if index == n:
        result.append(' '.join(subStrList))
    for i in range(index+1, n+1):
        if s[index:i] in wordDict:
            subStrList.append(s[index:i])
            backTrack(s, wordDict, subStrList, result, i)
            subStrList = []


def wordBreak(s, wordDict):
    m = len(s)
    n = len(wordDict)
    if n == 0:
        return []
    dp = [False]*(m+1)
    dp[0] = True
    subStrList = []
    index = 0
    result = []

    for i in range(m):
        for elem in wordDict:
            if dp[i] and i+len(elem) <= m:
                if s[i:i+len(elem)] == elem:
                    dp[i+len(elem)] = True
    if dp[m]:
        backTrack(s, wordDict, subStrList, result, index)
        return result
    else:
        return []

s = "leetcode"
wordDict = ["leet", "code"]
s1 = "applepenapple"
wordDict1 = ["apple", "pen"]
s2 = "catsandog"
wordDict2 = ["cats", "dog", "sand", "and", "cat"]
s3 = "a"
wordDict3 = []
s4 = "bb"
wordDict4 = ["a","b","bbb","bbbb"]
s5 = "catsanddog"
wordDict5 = ["cat","cats","and","sand","dog"]
print(wordBreak(s5, wordDict5))
